function addRecommendation(){

let text=document.getElementById("newRec").value;

if(text!=""){

let div=document.createElement("div");
div.className="rec";
div.innerText=text;

document.getElementById("recommendations").appendChild(div);

document.getElementById("popup").style.display="block";

}

}

function closePopup(){
document.getElementById("popup").style.display="none";
}

function goTop(){
window.scrollTo(0,0);
}
